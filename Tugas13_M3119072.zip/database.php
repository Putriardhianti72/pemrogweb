<?php
$koneksi1=mysqli_connect('localhost','root','','pemrogweb');
?>